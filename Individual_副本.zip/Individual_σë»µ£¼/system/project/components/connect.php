<?php

$db_host = 'localhost'; // 主机名
$db_name = 'shop_db'; // 数据库名
$db_user_name = 'root'; // 数据库用户名
$db_user_pass = ''; // 数据库密码
$db_port = 3307; // 端口号

// PDO 连接字符串，包括端口号
$dsn = "mysql:host=$db_host;dbname=$db_name;port=$db_port";

try {
    $conn = new PDO($dsn, $db_user_name, $db_user_pass);
    // 设置 PDO 错误模式为异常
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully"; 
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

function create_unique_id(){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < 20; $i++) {
        $randomString .= $characters[mt_rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>